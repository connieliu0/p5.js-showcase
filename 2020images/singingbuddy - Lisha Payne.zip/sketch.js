var mouthHeight;
var canvasX = 500;
var canvasY = 500;
var value = 0;
var prevValue = 0;
let note1, note2, note3, note4, note5, note6, note7, note8;

let toggle1 = false;
let toggle2 = false;
let toggle3 = false;
let toggle4 = false;
let toggle5 = false;
let toggle6 = false;
let toggle7 = false;
let toggle8 = false;

function preload() {
  note1 = loadSound('v-01.mp3');
  note2 = loadSound('v-02.mp3');
  note3 = loadSound('v-03.mp3');
  note4 = loadSound('v-04.mp3');
  note5 = loadSound('v-05.mp3');
  note6 = loadSound('v-06.mp3');
  note7 = loadSound('v-07.mp3');
  note8 = loadSound('v-08.mp3');
}

function setup() {
  loadCamera(canvasX, canvasY);
  loadTracker();
  loadCanvas(canvasX, canvasY);
  //Keyboard
  cButton = createButton('C');
  dButton = createButton('D');
  eButton = createButton('E');
  fButton = createButton('F');
  gButton = createButton('G');
  aButton = createButton('A');
  bButton = createButton('B');
  cButton2 = createButton('C');
}

function draw() {
  getPositions();

  if (positions.length == 71 && ctracker.getScore() > 0.3) {
    value = positions[53][1] - positions[47][1];
    prevValue = value;
    background(255, 255, 153, 10);
    //background(255);

  } else {
    value = prevValue;
    background(255, 0, 0);

  }

  //console.log(value);
  //console.log(ctracker.getScore());
  mouthHeight = map(value, 25, 70, -30, 100);

  //EYES
  fill(255)
  stroke(5)
  ellipse(125, 120, 50, 30)
  ellipse(375, 120, 50, 30)
  //EYEBROWS
  stroke(0, 0, 0);
  noFill();
  eyebrowHeight = map(value / 2, 10, 40, 100, 80)
  arc(120, eyebrowHeight, 40, 35, PI + QUARTER_PI, PI + HALF_PI + QUARTER_PI);
  arc(380, eyebrowHeight, 40, 35, PI + QUARTER_PI, PI + HALF_PI + QUARTER_PI);
  fill(0);
  ellipse(125, 120, 30, 30)
  ellipse(375, 120, 30, 30)
  //MOUTH
  ellipse(250, 200, 100, value)
  //NOSE
  noStroke()
  fill(255, 182, 193, 20)
  arc(250, 145, 40, 30, 0, PI, CHORD);
  rect(240,85,20,60)
  //CHEEK
  cheekAlpha = map(value, 20, 50, 50, 100)
  fill(210, 115, 95, cheekAlpha)
  ellipse(125, 180, 50, 50)
  ellipse(375, 180, 50, 50)

  //KEYBOARD//
  cButton.position(50, 350);
  cButton.mousePressed(cPressed);
  cButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  dButton.position(100, 350);
  dButton.mousePressed(bPressed);
  dButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  eButton.position(150, 350);
  eButton.mousePressed(ePressed);
  eButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  fButton.position(200, 350);
  fButton.mousePressed(fPressed);
  fButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  gButton.position(250, 350);
  gButton.mousePressed(gPressed);
  gButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  aButton.position(300, 350);
  aButton.mousePressed(aPressed);
  aButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  bButton.position(350, 350);
  bButton.mousePressed(bPressed);
  bButton.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  cButton2.position(400, 350);
  cButton2.mousePressed(cPressed2);
  cButton2.style('background-color: rgb(255,255,255); color: black; font-size: 16px; padding: 10px 10px;');

  noteVolume = map(value, 25, 80, 0, 1)
  note1.setVolume(noteVolume)
  note2.setVolume(noteVolume)
  note3.setVolume(noteVolume)
  note4.setVolume(noteVolume)
  note5.setVolume(noteVolume)
  note6.setVolume(noteVolume)
  note7.setVolume(noteVolume)
  note8.setVolume(noteVolume)
}

function cPressed() {
  if (!toggle1) {
    note1.loop();
    toggle1 = !toggle1;
  } else {
    note1.stop();
    toggle1 = !toggle1;
  }

}

function dPressed() {
    if (!toggle2) {
      note2.loop();
      toggle2 = !toggle2;
  } else {
      note2.stop();
      toggle2 = !toggle2;
  }
}

function ePressed() {
    if (!toggle3) {
      note3.loop();
      toggle3 = !toggle3;
  } else {
      note3.stop();
      toggle3 = !toggle3;
  }
}

function fPressed() {
    if (!toggle4) {
      note4.loop();
      toggle4 = !toggle4;
  } else {
    note4.stop();
    toggle4 = !toggle4;
  }
}

function gPressed() {
    if (!toggle5) {
      note5.loop();
      toggle5 = !toggle5;
  } else {
    note5.stop();
    toggle5 = !toggle5;
  }
}

function aPressed() {
    if (!toggle6) {
      note6.loop();
      toggle6 = !toggle6;
  } else {
    note6.stop();
    toggle6 = !toggle6;
  }
}

function bPressed() {
    if (!toggle7) {
      note7.loop();
      toggle7 = !toggle7;
  } else {
    note7.stop();
    toggle7 = !toggle7;
  }
}

function cPressed2() {
    if (!toggle8) {
      note8.loop();
      toggle8 = !toggle8;
  } else {
    note8.stop();
    toggle8 = !toggle8;
  }

}

function keyPressed() {
  if (key == '1') {
    note1.loop();
  }
  if (key == '2') {
    note2.loop();
  }
  if (key == '3') {
    note3.loop();
  }
  if (key == '4') {
    note4.loop();
  }
  if (key == '5') {
    note5.loop();
  }
  if (key == '6') {
    note6.loop();
  }
  if (key == '7') {
    note7.loop();
  }
  if (key == '8') {
    note8.loop();
  }
}

function keyReleased() {
  if (key == '1') {
    note1.stop();
  }
  if (key == '2') {
    note2.stop();
  }
  if (key == '3') {
    note3.stop();
  }
  if (key == '4') {
    note4.stop();
  }
  if (key == '5') {
    note5.stop();
  }
  if (key == '6') {
    note6.stop();
  }
  if (key == '7') {
    note7.stop();
  }
  if (key == '8') {
    note8.stop();
  }
}